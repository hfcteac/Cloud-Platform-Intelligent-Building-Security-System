#include "stm32f10x.h"
#include "led.h"
#include "key.h"
#include "OLED.h"
#include "delay.h"
#include "sensor.h"
#include "buzzer.h"
#include "usart.h"
#include "DHT112.h"
#include "step_motor.h"
#include <string.h>
#include <stdlib.h>
#include <limits.h>
#include <stdio.h>

int main(void)
{ 
	
	delay_init();
	Led_Init();	
	Key_Init();
	OLED_Init();
	PIR_Init();	
	SRD_Init();
	ADC1_Init();
	DHT11_Init();
	DHT112_Init();
  delay_ms(1000); 	
	step_motor_gpio_init();
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_3); //����NVIC�жϷ���2:2λ��ռ���ȼ���2λ��Ӧ���ȼ�
	uart_init(9600);	 //���ڳ�ʼ��Ϊ9600
  ///�����ȶ�������ʱ	
	DHT11_Read_Data(&sys_ctrl.temp,&sys_ctrl.humi);	
	DHT112_Read_Data(&sys_ctrl.outtemp,&sys_ctrl.outhumi);
	delay_ms(1000);
	DHT11_Read_Data(&sys_ctrl.temp,&sys_ctrl.humi);	
	DHT112_Read_Data(&sys_ctrl.outtemp,&sys_ctrl.outhumi);
	delay_ms(1000);
	///������
	while(1){ 
		is_bad();
		SRD_Start();

  }		
}
