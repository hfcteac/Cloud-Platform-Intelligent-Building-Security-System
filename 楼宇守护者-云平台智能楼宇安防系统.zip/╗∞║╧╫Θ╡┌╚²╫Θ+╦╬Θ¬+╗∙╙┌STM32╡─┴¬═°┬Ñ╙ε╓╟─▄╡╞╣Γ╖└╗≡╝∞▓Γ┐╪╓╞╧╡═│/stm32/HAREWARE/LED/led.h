#ifndef __LED_H
#define __LED_H

void Led_Init(void); //LED��ʼ��
#endif


