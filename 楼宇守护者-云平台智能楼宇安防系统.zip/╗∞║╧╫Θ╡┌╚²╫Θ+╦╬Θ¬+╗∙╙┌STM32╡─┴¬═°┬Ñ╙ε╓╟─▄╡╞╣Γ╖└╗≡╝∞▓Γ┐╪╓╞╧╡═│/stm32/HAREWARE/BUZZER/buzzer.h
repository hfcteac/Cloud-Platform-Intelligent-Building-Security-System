#ifndef _BUZZER_H
#define _BUZZER_H

void bj90(void); //步进电机转90度
void bjf90(void);//步进电机倒90度
void bj180(void); //步进电机转180度
void bjf180(void);//步进电机倒180度
void bj270(void); //步进电机转270度
void bjf270(void);//步进电机倒270度
void daoxiang(void);//瞎寄吧显示稻香

#endif

